package br.edu.ifsp.spo.java.cards.itens;

public enum Valor {
    AS, DOIS, TRES, QUATRO, CINCO, SEIS, SETE, OITO, NOVE, DEZ, DAMA, VALETE, REI;
}
